|接口| 接口功能 | Action ID | 
|---------|---------|---------|
|[文本翻译API](/document/product/551/7380)| 文本翻译，目前提供中文到英日韩，英日韩到中文的翻译功能 | TextTranslate| 
|[语言识别API](/document/product/551/7467)| 识别文本语种，目前可以识别的语言有中英日韩 | LanguageDetect|
|[图片翻译API](/document/product/551/9907)| 图片内文字识别和翻译，目前提供中英互译功能 | ImageTranslate|
|[语音翻译API](/document/product/551/11372)| 音频内文字识别和翻译，目前提供中英互译功能 | SpeechTranslate|
