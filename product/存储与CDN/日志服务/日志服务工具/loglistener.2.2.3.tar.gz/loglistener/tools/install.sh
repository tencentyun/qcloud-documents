#!/bin/bash

if [ -z "$3" ];then
	echo "Usage ./install id key region(ap-beijing|ap-shanghai|ap-guangzhou|ap-chengdu|ap-hongkong|na-toronto|na-ashburn|ap-shenzhen-fsi|ap-shanghai-fsi) [group_ip]"
	exit
fi

reg="^(([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-5])$"

regions="beijing shanghai guangzhou chengdu hongkong"

conf_regions=$3

for region in $regions
do
    if [ $conf_regions = $region ]
    then
        conf_regions="ap-"$region
        break
    fi
done

regions="ap-beijing ap-shanghai ap-guangzhou ap-chengdu ap-hongkong na-toronto na-ashburn ap-shenzhen-fsi ap-shanghai-fsi"
bfind=0
for region in $regions
do
    if [ $conf_regions = $region ]
    then
        bfind=1
        break
    fi
done


if [ $bfind -eq 0 ]
then
	echo "Usage ./install id key region(ap-beijing|ap-shanghai|ap-guangzhou|ap-chengdu|ap-hongkong|na-toronto|na-ashburn|ap-shenzhen-fsi|ap-shanghai-fsi) [group_ip]"
    exit
fi

CENTOS="CentOS"
UBUNTU="Ubuntu"
DEBIAN="Debian"
TLINUX="tlinux"
OPENSUSE="openSUSE"
OTHER="otheros"

VOS=$OTHER
issue=`cat /etc/issue | tr A-Z a-z`
centos_release_file="/etc/centos-release"
if [ `echo $issue | grep debian | wc -l` -ge 1 ]; then
    VOS=$DEBIAN
elif [ `echo $issue | grep ubuntu | wc -l` -ge 1 ]; then
    VOS=$UBUNTU
elif [ `echo $issue | grep centos | wc -l` -ge 1 ] || [ -f $centos_release_file ]; then
    VOS=$CENTOS
elif [ `echo $issue | grep tlinux | wc -l` -ge 1 ]; then
    VOS=$TLINUX
elif [ `echo $issue | grep opensuse | wc -l` -ge 1 ]; then
    VOS=$OPENSUSE
fi

cd `dirname $0`/../
base_path=`pwd`
path_new=`echo ${base_path//\//\\\/}`
#echo "$base_path"
mkdir -p log
mkdir -p data

if [ ! -z $4 ]
then
    num=`echo  $4 |egrep $reg -c`
    if [ $num -ne 1 ]
    then
        echo "your input groupip is error [$4]"
        exit 1
    fi
    group_ip=$4
else
    ips=(`bin/getip`)
    if [ ${#ips[@]}  -eq 1 ]
    then
        group_ip=${ips[0]}
    else
        echo "get ip is:${ips[@]}"

        while :
        do
            read -p "please enter your ip:" group_ip
            num=`echo  ${group_ip} |egrep $reg -c`
            if [ $num -eq 1 ]
            then
                break
            else
                echo "input group ip error!"
            fi
        done
    fi
fi


#cd $path_tools/../etc
cp etc/loglistener.conf.temple etc/loglistener.conf.tmp
sed -i 's/proxy_host *=.*/proxy_host = '${conf_regions}'.cls.myqcloud.com/' etc/loglistener.conf.tmp
sed -i 's/secret_id *=.*/secret_id = '$1'/' etc/loglistener.conf.tmp
sed -i 's/secret_key *=.*/secret_key = '$2'/' etc/loglistener.conf.tmp
sed -i 's/group_ip *=.*/group_ip = '${group_ip}'/' etc/loglistener.conf.tmp
mv etc/loglistener.conf.tmp etc/loglistener.conf
chmod 0600 etc/loglistener.conf

cp tools/loglistenerd.temple tools/loglistenerd.tmp
sed -i 's/BASE_DIR=.*/BASE_DIR='${path_new}'/' tools/loglistenerd.tmp
chmod 755 tools/loglistenerd.tmp
mv tools/loglistenerd.tmp /etc/init.d/loglistenerd

if [ $VOS = $TLINUX ] || [ $VOS = $CENTOS ] || [ $VOS = $OPENSUSE ]; then
    chkconfig --add loglistenerd
fi

tools/start.sh

echo "group ip is :${group_ip}"
echo "OK"


