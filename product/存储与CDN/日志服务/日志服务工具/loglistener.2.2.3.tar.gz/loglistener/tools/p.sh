#!/bin/bash
#V2.0 
#p.sh

ps -ef   2>/dev/null |grep loglistener| grep -v grep

