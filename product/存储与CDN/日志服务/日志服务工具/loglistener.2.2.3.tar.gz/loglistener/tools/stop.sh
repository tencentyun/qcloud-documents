#!/bin/bash

cd `dirname $0`/../

CENTOS="CentOS"
UBUNTU="Ubuntu"
DEBIAN="Debian"
TLINUX="tlinux"
OPENSUSE="openSUSE"
OTHER="otheros"

VOS=$OTHER
issue=`cat /etc/issue | tr A-Z a-z`
centos_release_file="/etc/centos-release"
if [ `echo $issue | grep debian | wc -l` -ge 1 ]; then
    VOS=$DEBIAN
elif [ `echo $issue | grep ubuntu | wc -l` -ge 1 ]; then
    VOS=$UBUNTU
elif [ `echo $issue | grep centos | wc -l` -ge 1 ] || [ -f $centos_release_file ]; then
    VOS=$CENTOS
elif [ `echo $issue | grep tlinux | wc -l` -ge 1 ]; then
    VOS=$TLINUX
elif [ `echo $issue | grep opensuse | wc -l` -ge 1 ]; then
    VOS=$OPENSUSE
fi

if [ $VOS = $TLINUX ] || [ $VOS = $CENTOS ] || [ $VOS = $OPENSUSE ]; then
    chkconfig loglistenerd off
elif [ $VOS = $DEBIAN ] || [ $VOS = $UBUNTU ]; then
    update-rc.d -f loglistenerd remove
else
    if [ -f /etc/rc.d/rc0.d/K45loglistenerd ]; then
        unlink /etc/rc.d/rc0.d/K45loglistenerd
    fi

    if [ -f /etc/rc.d/rc1.d/K45loglistenerd ]; then
        unlink /etc/rc.d/rc1.d/K45loglistenerd
    fi

    if [ -f /etc/rc.d/rc2.d/S55loglistenerd ]; then
        unlink /etc/rc.d/rc2.d/S55loglistenerd
    fi

    if [ -f /etc/rc.d/rc3.d/S55loglistenerd ]; then
        unlink /etc/rc.d/rc3.d/S55loglistenerd
    fi

    if [ -f /etc/rc.d/rc4.d/S55loglistenerd ]; then
        unlink /etc/rc.d/rc4.d/S55loglistenerd
    fi

    if [ -f /etc/rc.d/rc5.d/S55loglistenerd ]; then
        unlink /etc/rc.d/rc5.d/S55loglistenerd
    fi

    if [ -f /etc/rc.d/rc6.d/K45loglistenerd ]; then
        unlink /etc/rc.d/rc6.d/K45loglistenerd
    fi
fi

killall -q loglistenerm
killall -q loglistener 
killall -q loglisteneru

exit 0

