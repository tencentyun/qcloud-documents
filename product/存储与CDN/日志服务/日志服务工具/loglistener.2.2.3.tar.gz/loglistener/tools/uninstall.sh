#!/bin/bash

cd `dirname $0`/../
path_tools=`pwd`

CENTOS="CentOS"
UBUNTU="Ubuntu"
DEBIAN="Debian"
TLINUX="tlinux"
OPENSUSE="openSUSE"
OTHER="otheros"

VOS=$OTHER
issue=`cat /etc/issue | tr A-Z a-z`
centos_release_file="/etc/centos-release"
if [ `echo $issue | grep debian | wc -l` -ge 1 ]; then
    VOS=$DEBIAN
elif [ `echo $issue | grep ubuntu | wc -l` -ge 1 ]; then
    VOS=$UBUNTU
elif [ `echo $issue | grep centos | wc -l` -ge 1 ] || [ -f $centos_release_file ]; then
    VOS=$CENTOS
elif [ `echo $issue | grep tlinux | wc -l` -ge 1 ]; then
    VOS=$TLINUX
elif [ `echo $issue | grep opensuse | wc -l` -ge 1 ]; then
    VOS=$OPENSUSE
fi

tools/stop.sh

if [ $VOS = $TLINUX ] || [ $VOS = $CENTOS ] || [ $VOS = $OPENSUSE ]; then
    chkconfig --del loglistenerd
    rm -f /etc/init.d/loglistenerd
fi


