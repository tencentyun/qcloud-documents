#!/bin/bash

cd `dirname $0`/../

grep cls.myqcloud.com /etc/hosts

if [ $? -eq 0 ]
then
    echo 
    echo "please check /etc/hosts"
    echo 
fi

bin/check


