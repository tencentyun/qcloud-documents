# python3 train.py --epochs 5 --log_dir /opt/ml/output/summary  --ckpt_dir /opt/ml/output --model_dir /opt/ml/model

# epochs  训练的epoch数

# log_dir  tensorboard文件输出路径

# ckpt_dir  checkpoint输出路径

# model_dir 最终模型文件输出路径