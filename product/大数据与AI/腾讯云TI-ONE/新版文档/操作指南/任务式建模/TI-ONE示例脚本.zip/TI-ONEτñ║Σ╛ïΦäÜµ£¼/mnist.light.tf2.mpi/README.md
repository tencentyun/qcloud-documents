# horovodrun -np $GPU_NUM -H $NODE_IP_SLOT_LIST --network-interface eth0 python3 light_tensorflow2_benchmark.py --data-path /opt/ml/input/data/

# --data-path 样本数据目录