## 登录小微 Skill 控制台

登录小微 Skill [控制台](https://xiaowei.qcloud.com/developer/skill-list)，单击右上角【新建技能】。

![](https://mc.qcloudimg.com/static/img/93e4a3087be6cc3111d03bc8a3460730/image.png)

## 输入基本信息

 1.输入【名称】，在【QSkill类型】处勾选【设备类型】，完成后单击右下角【提交】。

![](https://mc.qcloudimg.com/static/img/c3af40c4f106eb179eb4c363ced3a0c2/image.png)

 2.选择【基本配置】，填写完必要信息后单击右下角【开始配置】。

![](https://mc.qcloudimg.com/static/img/364a31032144d487fc620ca112d4d219/image.png)

 3.授权模式选择【授权码访问模式】，填写完必要信息后点击【保存】

![](https://mc.qcloudimg.com/static/img/67323870ffd1a86866c9fe7585d3454d/image.png)

## 开启测试训练

 1.选择【测试训练】，在【是否开启测试训练】勾选。

 ![](https://mc.qcloudimg.com/static/img/3d0a0daa425291b8b43681eee60784d4/image.png)

 ## 发布 Skill

 1. 选择【发布】，填写发布内容信息，完成后选择【保存配置】可以保存本次填写的信息，【提交审核】可以将本次填写的信息提交给我们审核，资料审核通过后便可以发布。

![](https://mc.qcloudimg.com/static/img/2f9e2fb3a62f07d099f267ef4ed6688c/image.png)
